import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.csvreader.CsvWriter;
import com.sun.org.apache.xpath.internal.functions.Function;


public class CountAll {

	public static void main(String[] args) {
		//File file = new File("file.txt");
		
		String everything = "";
		
		int topValue = 5;//this the value coming from URL
		
		Scanner file = null;
		try {
			file = new Scanner(new File("file.txt")).useDelimiter("[^a-zA-Z]+");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   HashMap<String, Integer> map = new HashMap<>();

		   while (file.hasNext()){
		        String word = file.next().toLowerCase();
		        if (map.containsKey(word)) {
		            map.put(word, map.get(word) + 1);
		        } else {
		            map.put(word, 1);
		        }
		    }

		    ArrayList<Map.Entry<String, Integer>> entries = new ArrayList<>(map.entrySet());
		    Collections.sort(entries, new Comparator<Map.Entry<String, Integer>>() {

		        @Override
		        public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
		            return b.getValue().compareTo(a.getValue());
		        }
		    });

		    String csv = "data.csv";
			CsvWriter writer = null;
			try {
				writer = new CsvWriter(new FileWriter(csv, true), ',');
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    
		    for(int i=0; i<topValue; i++){
		    	System.out.println(entries.get(i));
		    	try {
					writer.write(entries.get(i).toString());
					writer.endRecord();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	
				
		    }
		    writer.close();
	}
	
	public void writeCsv(){
		
		
	}

}
