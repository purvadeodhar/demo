import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.String;
import java.nio.charset.Charset;

import com.google.gson.Gson;


public class Test {
	protected static Charset utf8 = Charset.forName("UTF-8");
	public static void main(String[] args) {
		
		System.out.println("hi");
		
		getWordCount();
	}
	
	public static final List getWordCount()
		{
		List<Map<String, Integer>> wordList =
		        new ArrayList<Map<String, Integer>>();
		Map<String, Integer> elementMap;
			String everything = "";
			try{
				BufferedReader br = new BufferedReader(new FileReader("file.txt"));//file can be kept in the same location as this class and content can be read
			    StringBuilder sb = new StringBuilder();
			    String line = br.readLine();

			    while (line != null) {
			        sb.append(line);
			        sb.append(System.lineSeparator());
			        line = br.readLine();
			    }
			    
			    everything = sb.toString();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String arr[] = new String[]{"Duis", "Sed", "Donec", "Augue", "Pellentesque", "luctus"};
			
			Map<String,String[]> map = new HashMap<String,String[]>();
			map.put("searchText", arr);
			String[] elements = map.get("searchText");
		     			
			for (String s: elements)
			{
				elementMap = new HashMap<String, Integer>();
				int i = 0;
				Pattern p = Pattern.compile(s);
				Matcher m = p.matcher(everything);
				while (m.find()) {
					i++;
				}
				elementMap.put(s, i);
				wordList.add(elementMap);
			}		
			
			Gson gson = new Gson();
			String json = gson.toJson(wordList);
			HashMap<String, Object> jsonMap = new HashMap<String, Object>();
		    jsonMap.put("counts", wordList);
			ByteArrayInputStream byteInputStream =
			        new ByteArrayInputStream(getJsonFromMap(jsonMap).getBytes(utf8));
			System.out.println("JSON data gson "+gson.toJson(jsonMap));
			return wordList;
		}
	
	public static String getJsonFromMap(Map<String, Object> pMap)
	  {

	    StringBuffer buffer = new StringBuffer();
	    buffer.append("{");
	    if (pMap != null)
	    {
	      String separator = "";
	      for (Entry entry : pMap.entrySet())
	      {
	        if (entry.getValue() != null)
	        {
	          String json = getJson(entry);
	          if (json != null)
	          {
	            buffer.append(separator);
	            buffer.append(json);
	            separator = ", ";
	          }
	        }
	      }
	    }
	    buffer.append("}");
	    return buffer.toString();
	  }
	
	private static String getJson(Object value)
	  {

	      if (value instanceof Collection)
	      {
	        return getJsonList((Collection)value);

	      }
	      else if (value instanceof Map)
	      {
	        return getJsonFromMap((Map)value);
	      }

	      return value.toString();

	  }
	
	public static String getJsonList(Collection<Object> list)
	  {
	    StringBuffer buffer = new StringBuffer();
	    buffer.append("[");
	    String separator = "";
	    for (Object object : list)
	    {
	      buffer.append(separator);
	      buffer.append(getJson(object));
	      separator = ", ";
	    }
	    buffer.append("]");

	    return buffer.toString();
	  }
}

